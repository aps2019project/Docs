import java.util.Arrays;
import java.util.Scanner;

public class Bikar {

    private static void invalidOutput() {
        System.out.println("Invalid Input");
    }

    private static boolean isInvalidInput(String[] cars) {
        for (String car : cars) {
            if (!car.matches("([a-z]|[0-9])+\\.\\d{3}\\.[A-Z]\\.\\d{2}\\.\\d{2}")) {
                return true;
            }
        }
        return false;
    }

    private static boolean isRepetitious(String[][] split) {
        for (int j = 0; j < split.length; j++) {
            if (split[j][0] == null) {
                break;
            }
            for (int i = j + 1; i < split.length; i++) {
                if (split[i][0] == null) {
                    break;
                }
                if (split[j][1].equals(split[i][1]) && split[j][2].equals(split[i][2]) && split[j][3].equals(split[i][3]) && split[j][4].equals(split[i][4])) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String firstCop;
        String secondCop;
        String[] firstData;
        String[] secondData;
        String[] sorted = new String[100];
        String[][] split = new String[100][6];
        firstCop = scanner.nextLine();
        secondCop = scanner.nextLine();
        if (firstCop.isEmpty() && secondCop.isEmpty()) {
            return;
        }
        firstData = firstCop.split("/");
        secondData = secondCop.split("/");
        if (isInvalidInput(firstData) || isInvalidInput(secondData)) {
            invalidOutput();
            return;
        }
        int i = 0;
        for (String string : firstData) {
            sorted[i] = Integer.toString(100 - Integer.parseInt(string.substring(string.length() - 2))) + "." + string.substring(0, string.length() - 3);
            i++;
        }
        for (String string : secondData) {
            sorted[i] = Integer.toString(100 - Integer.parseInt(string.substring(string.length() - 2))) + "." + string.substring(0, string.length() - 3);
            i++;
        }
        Arrays.sort(sorted, 0, i);
        for (int j = 0; j < i; j++) {
            split[j] = sorted[j].split("\\.");
        }
        if (isRepetitious(split)) {
            invalidOutput();
            return;
        }
        for (String[] carData : split) {
            if (carData[0] == null) {
                return;
            }
            System.out.println(carData[1] + "->" + carData[2] + "." + carData[3] + "." + carData[4] + " ,probability: " + (100 - Integer.parseInt(carData[0])));
        }
    }
}
