import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Eshterak {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] sizes = new int[n];
        for (int i = 0; i < n; i++)
            sizes[i] = scanner.nextInt();
        ArrayList<Integer> list = null, current;
        for (int i = 0; i < n; i++) {
            current = new ArrayList<>(sizes[i]);
            for (int j = 0; j < sizes[i]; j++) {
                current.add(scanner.nextInt());
            }
            Collections.sort(current);
            list = Intersection(list, current);
        }
        for (int x : list) {
            System.out.print(x + " ");
        }
    }

    private static ArrayList<Integer> Intersection(ArrayList<Integer> list1, ArrayList<Integer> list2) {
        if (list1 == null) {
            return list2;
        }
        ArrayList<Integer> result = new ArrayList<>();
        int x = 0, y = 0;
        while (x < list1.size() && y < list2.size()) {
            if (list1.get(x).equals(list2.get(y))) {
                result.add(list1.get(x));
                x++;
                y++;
            } else if (list1.get(x) < list2.get(y)) {
                x++;
            } else {
                y++;
            }
        }
        return result;
    }
}
