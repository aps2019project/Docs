import java.util.Scanner;

public class Lim {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n, m, k;
        n = scanner.nextInt();
        m = scanner.nextInt();
        k = scanner.nextInt();
        for (int i = 0; i < 2 * n + 1; i++) {
            StringBuilder builder = new StringBuilder();
            for (int l = 0; l < k; l++)
                for (int j = 0; j < 2 * n + m; j++)
                    builder.append((Math.min(j, 2 * n + m - 1 - j) + Math.min(i, 2 * n - i) < n) ? ' ' : '*');
            System.out.println(builder);
        }
    }
}
