import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Integer.min;

public class Shayea {
    private static Scanner scanner = new Scanner(System.in);
    private static int[] cost;
    private static List<List<Integer>> adj = new ArrayList<>();
    private static boolean[] visited;

    public static void main(String[] args) {
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        cost = new int[n];
        visited = new boolean[n];
        for (int i = 0; i < n; i++) {
            cost[i] = scanner.nextInt();
            adj.add(new ArrayList<>());
        }
        for (int i = 0; i < m; i++) {
            int temp1 = scanner.nextInt() - 1;
            int temp2 = scanner.nextInt() - 1;
            adj.get(temp1).add(temp2);
            adj.get(temp2).add(temp1);
        }
        long answer = 0;
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                answer += (long) dfs(i);
            }
        }
        System.out.println(answer);
    }

    public static int dfs(int v) {
        visited[v] = true;
        int res = cost[v];
        for (Integer v0 : adj.get(v)) {
            if (!visited[v0]) {
                res = min(res, dfs(v0));
            }
        }
        return res;
    }
}
