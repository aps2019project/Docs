import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Decoding {

    public enum OperatorType {
        Cpy, Mul, Add, CFWord, SWord, EnToNum
    }

    public static class Decoder {
        private String str;
        static String endGameKeyword = "@";

        Decoder(String string) {
            this.str = string.toLowerCase();
        }

        public String getStr() {
            return str;
        }

        private String enToNum(String s) {
            if (s.equals("zero")) return "0";
            if (s.equals("one")) return "1";
            if (s.equals("two")) return "2";
            if (s.equals("three")) return "3";
            if (s.equals("four")) return "4";
            if (s.equals("five")) return "5";
            if (s.equals("six")) return "6";
            if (s.equals("seven")) return "7";
            if (s.equals("eight")) return "8";
            if (s.equals("nine")) return "9";
            return "";
        }

        public boolean endGame(String previousResult) {
            if ((previousResult + this.str).contains(endGameKeyword))
                return true;
            return false;
        }

        private boolean CFWord(Operator operator) {
            String patternString = String.format("%s([\\w]{4})", operator.getKeyword());
            Pattern pattern = Pattern.compile(patternString);
            Matcher matcher = pattern.matcher(str);
            if (matcher.find()) {
                endGameKeyword = matcher.group(1);
                str = matcher.replaceFirst("");
                return true;
            }
            return false;
        }

        private boolean copy(Operator operator) {
            String keyword = operator.getKeyword();
            String patternString = String.format("(%s)(\\d)?", keyword);
            Pattern pattern = Pattern.compile(patternString);
            Matcher matcher = pattern.matcher(str);
            if (matcher.find()) {
                int count = -1;
                try {
                    count = Integer.parseInt(matcher.group(2));
                } catch (Exception e) {
                }
                if (count == -1) {
                    count = keyword.length();
                    patternString = String.format("(%s)([\\w]{%d})", keyword, count);
                } else
                    patternString = String.format("(%s)%d([\\w]{%d})", keyword, count, count);
                pattern = Pattern.compile(patternString);
                matcher = pattern.matcher(str);
                if (matcher.find()) {
                    str = matcher.replaceFirst(matcher.group(2) + matcher.group(2));
                    return true;
                }
            }
            return false;
        }

        private boolean SWord(Operator operator) {
            String keyword = operator.getKeyword();
            int requiredCount = operator.getCount();
            int count = 0;
            String patternString = "(" + keyword + ")";
            Pattern pattern = Pattern.compile(patternString);
            Matcher matcher = pattern.matcher(str);
            while (matcher.find())
                count++;
            if (count < requiredCount)
                return false;
            count = 0;
            while (count < requiredCount) {
                matcher = pattern.matcher(str);
                if (matcher.find())
                    str = matcher.replaceFirst("");
                count++;
            }
            return true;
        }

        private boolean addOrMul(Operator operator, boolean isAdd) {
            String keyword = operator.getKeyword();
            String patternString = String.format("([\\d]+)%s([\\d]+)", keyword);
            Pattern pattern = Pattern.compile(patternString);
            Matcher matcher = pattern.matcher(str);
            if (matcher.find()) {
                int num1 = Integer.parseInt(matcher.group(1));
                int num2 = Integer.parseInt(matcher.group(2));
                if (isAdd)
                    str = matcher.replaceFirst("" + (num1 + num2));
                else
                    str = matcher.replaceFirst("" + (num1 * num2));
                return true;
            }
            return false;
        }

        private boolean enToNum() {
            Pattern pattern = Pattern.compile("(zero|one|two|three|four|five|six|seven|eight|nine|ten)");
            Matcher matcher = pattern.matcher(str);
            boolean result = false;
            while (matcher.find()) {
                str = matcher.replaceFirst(enToNum(matcher.group(1)));
                matcher = pattern.matcher(str);
                result = true;
            }
            return result;
        }

        public boolean applyOperator(Operator operator) {
            switch (operator.getOperatorType()) {
                case Cpy:
                    return copy(operator);
                case Add:
                    return addOrMul(operator, true);
                case Mul:
                    return addOrMul(operator, false);
                case EnToNum:
                    return enToNum();
                case CFWord:
                    return CFWord(operator);
                case SWord:
                    return SWord(operator);
                default:
                    return false;
            }
        }
    }

    public static class Operator {
        private String keyword;
        private OperatorType operatorType;
        private int count;

        Operator(String keyword, OperatorType operatorType, int count) {
            this.keyword = keyword;
            this.operatorType = operatorType;
            this.count = count;
        }

        OperatorType getOperatorType() {
            return operatorType;
        }

        String getKeyword() {
            return keyword;
        }

        int getCount() {
            return count;
        }

        @Override
        public String toString() {
            String r = this.operatorType.toString() + ": " + this.keyword;
            if (this.count != 0)
                r += " " + this.count;
            return r;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder previousResults = new StringBuilder();
        boolean isEnded = false;
        while (!isEnded) {
            String operatorsInput = scanner.nextLine();
            Pattern pattern = Pattern.compile("(\\w+):\\s(\\w+)(\\s(\\d))?");
            Matcher matcher = pattern.matcher(operatorsInput);
            ArrayList<Operator> operators = new ArrayList<>();
            while (matcher.find()) {
                String keyword = matcher.group(2);
                OperatorType type = OperatorType.valueOf(matcher.group(1));
                int count = 0;
                try {
                    count = Integer.parseInt(matcher.group(4));
                } catch (Exception ignored) {
                }
                operators.add(new Operator(keyword, type, count));
            }
            operators.add(new Operator("", OperatorType.EnToNum, 0));
            boolean continueDecoding = true;
            Decoder decoder = new Decoder(scanner.nextLine());
            while (continueDecoding) {
                boolean completed = false;
                for (Operator operator : operators) {
                    completed = decoder.applyOperator(operator);
                    if (decoder.endGame(previousResults.toString())) {
                        isEnded = true;
                        continueDecoding = false;
                        break;
                    }
                    if (completed) {
                        if (operator.getOperatorType() == OperatorType.SWord)
                            continueDecoding = false;
                        break;
                    }
                }
                if (!completed)
                    continueDecoding = false;
            }
            System.out.println(decoder.getStr());
            previousResults.append(decoder.getStr());
        }
    }
}

